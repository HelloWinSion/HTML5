#创建用户销售表
CREATE TABLE xz_sal(
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(25),
  value  INT
);
INSERT INTO xz_sal VALUES(null,'北京',190);
INSERT INTO xz_sal VALUES(null,'天津',120);
INSERT INTO xz_sal VALUES(null,'上海',110);
INSERT INTO xz_sal VALUES(null,'广州',90);
